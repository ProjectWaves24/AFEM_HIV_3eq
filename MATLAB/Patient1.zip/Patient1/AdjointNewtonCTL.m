%Computes the adjoint solution of the model problem.
function [lambda] = AdjointNewtonCTL(d_CTL, eta, u, g, time_mesh, obs_start, obs_end)

final_time = time_mesh(end); % here we choose the final time
nodes = length(time_mesh);

t=final_time;  % final  time in adjoint solver, the same final time is in the forward problem

lambdastart = [0;0;0];    % values for lambda(T)= 0 at the final time

w = lambdastart;

MaxIter = 1000;  % maximal number of iterations in Newton's method

lambda = zeros(3,nodes);
lambda(:,nodes) = lambdastart;

%dt = final_time/nodes;   %Time step
dt = zeros(1,length(time_mesh));
for i = 1:length(dt)-1
    dt(i) = time_mesh(i+1)-time_mesh(i);   %Time step
end

%i = nodes + 1;
for i = nodes:-1:2   
    adjtol=1;adjiter=0;
    while adjtol>10^(-5) && adjiter < MaxIter   %Newton iterations
        %if low < i && high > i
%        adjF = w - lambda(:,i) + dt*adjfunc(w,u(:,i),g(:,i),eta(i));
        if t >= obs_start && t <= obs_end
            adjF = w - lambda(:,i) + dt(i)*adjfunc2CTL(d_CTL(i),w,u(:,i),g(:,i),eta(i)); 
        else
            adjF = w - lambda(:,i) + dt(i)*adjfuncCTL(d_CTL(i),w,u(:,i),eta(i));     %Do not include observations outside observation interval.
        end
%        adjJ = eye(length(lambdastart)) + dt.*adjfuncJac(u(:,i),eta(i));
        adjJ = eye(length(lambdastart)) + dt(i)*adjfuncJacCTL(d_CTL(i),u(:,i),eta(i));
        dw = -adjJ\adjF;
       w=w+dw;              %The Newton iteration 
       adjiter = adjiter +1;
       adjtol = norm(dw,inf);
    end  
    if adjiter==MaxIter        %If the Newton meth. does not converge
        disp('No convergence in the Newton method for adjoint problem')
        break
    end
      %disp('Newton method for adjoint problem converged at iteration:')
      %iter
    %i = i - 1;
    lambda(:,i-1) = w;        
    t=t-dt(i);
   %lambda_hist=[lambda_hist,lambda];
   %time_hist = [t,time_hist];

end



%************  plotting of all 3 solutions *******************

%figure
%plot(time_mesh,log10(lambda(1,:)),':  m','LineWidth',2);
%hold on;
%plot(time_mesh,log10(lambda(2,:)),'-- b','LineWidth',2);
%plot(time_mesh,log10(lambda(3,:)),'-  r','LineWidth',2);


%xlabel('time interval, days');
%ylabel('log_{10} \lambda(t)');
%legend('log_{10} \lambda_1','log_{10} \lambda_2','log_{10} \lambda_3','Location','SouthEast');

%legend('log_{10} \lambda_1','log_{10} \lambda_2','log_{10} \lambda_3');

%str_title = [' E = ', num2str(eta(1))];

%title(str_title)
%saveas(gcf,'lambda.png');


end
