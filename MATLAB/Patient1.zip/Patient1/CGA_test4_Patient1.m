% ACGA for Patient 1 ( 3 ODE)
%******************************************************
%% Specify fixed parameter values.
clear all
close all   
%Time parameters ----------------------------------------------------------
final_time = 363;
%final_time = 53;
%obs_start = 25;            %Starting time for observations of true solution.
obs_start = 0;   
obs_end = 363;            %End time for observations of true solution.
%obs_end = 53; 

%Optimization parameters --------------------------------------------------

gamma_start = 1.0;        %Initial value of regularization parameter.

opt_step_length = 0.1;  %Step length in optimization algorithm  eta: we can change it later
optim_maxiter = 30;      %Maximum iterations of optimization alg.

%m=53;  %number of initial observations in weeks (number of initial points in the time-mesh)
m=  364;  %number of initial observations in days (number of initial points in the time-mesh)
  
time_mesh =linspace(0,final_time ,m);

%*********  mesh refinements parameters

% maximal number of mesh refinements
maxmeshref = 5;

timemesh_hist = zeros(maxmeshref,1);

% initialize different mesh refinement parameters
nrbeta = 5;
meshref_beta = linspace(0.5,1,nrbeta);

ref_residual_hist = ones(optim_maxiter,nrbeta,maxmeshref);

%****************************
%Parameter E  for the model problem: initial guess 
E= zeros(1,length(time_mesh));
coef= zeros(1,length(time_mesh));
%initial guess for the parameter E 

E(1,:) = 1.0;


%*********************************
%final_time = time_mesh(end);
time_moments = length(time_mesh)-1;

ustart = [1125000;0;1];    %Initial values for u - write correct values

dt = zeros(1,length(time_mesh));
for i = 1:length(dt)-1
  dt(i) = time_mesh(i+1)-time_mesh(i);   %Time step
end


%*****************************

refined = time_mesh;

iteration_mesh = 1:optim_maxiter
  
eps = 10^(-12);

%************* Initialization: generation of data for Virus function

% we interpolate now only data for virus function
% here we interpolate data from weeks (52 weeks) to the data in days for one year (364 days)

		n= -1;
	     	p = 52;

      		% data for patient 1
            observations_V = Function_LinearIntVDaysPatient1(n,p);
                observations_V = 10.^observations_V;

	      observations_Sigma = Function_LinearIntSigmaDaysPatient1(n,p);
                observations_Sigma = 10.^observations_Sigma;

%parameters in simulatin of CTL response in Test 1

delta_ctl = 0.26;

% this value is good one to achieve  minimum in the acute stage  for Patient 1
beta_ctl = 0.015;


t1_ctl = 1;
t2_ctl =  1;

deltaT1 = 2.5;
deltaT2 = 5;

[d_CTL, E_CTL] = Function_InitDeltaPatient1(delta_ctl, beta_ctl, t1_ctl, t2_ctl, deltaT1, deltaT2, observations_V, time_mesh, E, observations_Sigma);


%% Run algorithm

% save   current time mesh
old_mesh = time_mesh;

%********************  here is the start for iterations on  adaptively refined time-meshes
%******************************************************************************************************
for meshref = 1:maxmeshref


	% we want to test different beta in the mesh refinement criterion on every mesh
	% we use one beta on the same mesh
		
     % for count_beta = 1:nrbeta

		
				     
    % This loop is for time adaptivity, will be replaced with while loop later.

	
			  
       time_mesh = refined;           %Our new time mesh (if mesh refinement has been made)	
       m=size(time_mesh,2);
       coef= zeros(1,length(time_mesh));
      										
      %compute smallest and largest time steps
     for i=1:m-1
        tau = time_mesh(1,i+1) - time_mesh(1,i);
        array_tau(i) = tau;
     end
      
     max_time_step = max(array_tau);
     min_time_step =  min(array_tau);


figure
%plot(array_tau,'o');
 bar(array_tau);

  str_title = ['Mesh size in  the refined meshes, nr. mesh ref.  ',num2str(meshref-1)];
	title(str_title);
	 saveas(gcf,'Meshsize.png');

	timemesh_hist(meshref) = size(time_mesh,2);

 %*******************************************************************
   
 % on refined meshes we need interpolate observations and parameters E, d into a new refined mesh
												
       	old_obs_V = log10(observations_V);
        old_obs_Sigma = log10(observations_Sigma);
        old_E = E_CTL;


        old_d_CTL = d_CTL; 
% here we interpolate observations for virus function
      	interpol_obs_V = Function_LinearInterpol(old_mesh, time_mesh, old_obs_V);
% here we interpolate observations for Sigma function
        interpol_obs_Sigma = Function_LinearInterpol(old_mesh, time_mesh, old_obs_Sigma);
% here we interpolate the function E --- immune response --- from old mesh to a new refined mesh
       	E_CTL =   Function_LinearInterpol(old_mesh,time_mesh,old_E);

% here we interpolate the function d_CTL  with CTL response--- immune response --- from old mesh to a new refined mesh
       	d_CTL =   Function_LinearInterpol(old_mesh,time_mesh,old_d_CTL);


       observations_V = 10.^interpol_obs_V;	
       observations_Sigma = 10.^interpol_obs_Sigma;
										

% here we assign  values of initial guess for   eta_guess = E_CTL   and observations g	
   
[eta_V, g_V] = GuessEta_fromVirus(E_CTL, observations_V, time_mesh, obs_start, obs_end, meshref);
[eta_Sigma, g_Sigma] = GuessEta_fromSigma(E_CTL, observations_Sigma, time_mesh, obs_start, obs_end, meshref);


% Merge the g matrix (observations)
g = zeros(3, length(time_mesh));
g(1,:) = g_Sigma(1,:);    % Sigma observations into g(1,:)
g(3,:) = g_V(3,:);        % Virus observations into g(3,:)

% Choosing initial guess (from virus or sigma)
%eta_guess = eta_V;        % Could also try 0.5*(eta_V + eta_Sigma) if needed
eta_guess = 0.5 * eta_V + 0.5 * eta_Sigma;  % Weighted average
% Optimization initialization
nodes = length(time_mesh);                                  %Number of nodes in the present time mesh.
    eta = zeros(optim_maxiter,nodes);                           %Preallocation of eta (for use in for-loop).
										    
	 iter = 1;									    
    eta(1,:) = eta_guess;                                       %First guess for eta in first row.
    beta = opt_step_length*ones(1,nodes);                 
    gamma = gamma_start;                            %Restore beta and gamma.
    big_grad = zeros(1,nodes);                      %Preallocation of vector for adaptivity.
  %**** compute solutions of forward and adjoint problems for initial guess E
  %                ********************************											
u1 = ForwardNewtonCTL(d_CTL,eta(1,:),time_mesh);                     %Compute initial forward sol.
lambda1 = AdjointNewtonCTL(d_CTL,eta(1,:),u1,g,time_mesh,obs_start,obs_end);   %Compute adjoint sol.

%********  visualization of u_3 in forward problem and compare it with measurements ************************************

figure
plot(time_mesh, log10(u1(3,:)), 'b-', 'LineWidth', 2) % Virus (u3)
hold on
  plot(time_mesh, log10(g(3,:)), 'm :', 'LineWidth', 2) % Observed virus

plot(time_mesh, log10(u1(1,:) + u1(2,:)), 'k -.', 'LineWidth', 2) % Sigma (T+I)
plot(time_mesh, log10(g(1,:)), 'r--', 'LineWidth', 2) % Observed Sigma

xlabel('Time (days)')
  ylabel('log_{10} V,      log_{10} \Sigma')
legend(' u_3', 'Observed V', '  u_1 + u_2', 'Observed \Sigma = T + I', 'Location', 'southwest')
title(['Patient 1: Virus and \Sigma = T + I dynamics  before optimization'])

if (meshref==1) 
	 saveas(gcf,'DynamicsInitref0.png');
elseif (meshref==2)
	 saveas(gcf,'DynamicsInitref1.png');
elseif (meshref==3)
	 saveas(gcf,'DynamicsInitref2.png');
elseif (meshref==4)
	 saveas(gcf,'DynamicsInitref3.png');
elseif  (meshref==5)
	 saveas(gcf,'DynamicsInitref4.png');
 else
    saveas(gcf,'DynamicsInitfinal.png');
end



if meshref == 1
    saveas(gcf, 'Sigmaref0.png');
elseif meshref == 2
    saveas(gcf, 'Sigmaref1.png');
elseif meshref == 3
    saveas(gcf, 'Sigmaref2.png');
elseif meshref == 4
    saveas(gcf, 'Sigmaref3.png');
elseif meshref == 5
    saveas(gcf, 'Sigmaref4.png');
else
    saveas(gcf, 'Sigmafinal.png');
end

%**********************************************************************************************************************
d=0.26;
% Extract T, I, lambda_2
T = u1(1,:);
I = u1(2,:);
lambda2 = lambda1(2,:);

% Compute virus term (same as before)
virus_grad = d * I .* lambda2;

% Compute Sigma = T + I
Sigma = T + I;
obs_Sigma = g(1,:);

% Avoid division by zero
Sigma(Sigma <= 0) = eps;
obs_Sigma(obs_Sigma <= 0) = eps;


% gradient is simply this part:
g0 =     virus_grad;

norm_grad_coef  = zeros(optim_maxiter,1);
norm_grad_hist  = zeros(optim_maxiter,1);

grad_hist = ones(optim_maxiter,nodes);
step_hist = ones(optim_maxiter,nodes);
step_hist(1,:) = beta;

    grad_hist(1,:) = g0;                                        %Save gradient for later plot.
% compute norm of the current gradient for analysis 
    refined_grad(meshref) = norm(g0);
      
    if norm(g0) < 1
        eta(1:end,:) = ones(length(1:optim_maxiter),1)*eta(1,:);    %Check if gradient is already small
        disp('The algorithm has converged at first step!')
        break
    end
    bm = 1/gamma;                          %For Conjugate Gradient algorithm.
    gn = -g0;
    dn = gn;
    g0 = sign(g0);                         %Normalize gradient.

    norm_grad_hist(1) = norm(g0);
    norm_grad_coef(1) =  norm(eta(1,:))/norm(eta(1,:));

   eta(2,:) = eta(1,:) + beta.*g0;             %Compute new eta.
 
    iterative_gamma(1) = gamma;


 %*************  here we start iterations in CGA  ***********************************************************
    for i = 2:optim_maxiter                                    %Here we start calculating E=eta

	      % iterative rule for reg.parameter
	gamma = gamma/i^0.5;                                        %Update iteratively reg. parameter gamma
% another iterative rule for updating reg. parameter gamma
%	gamma = gamma_start/(i+1)^0.5;


	iterative_gamma(i) = gamma;
u = ForwardNewtonCTL(d_CTL,eta(i,:),time_mesh);                      %Update forward and adjoint sol.
lambda = AdjointNewtonCTL(d_CTL,eta(i,:),u,g,time_mesh,obs_start,obs_end);


       	T = u(1,:);
I = u(2,:);
lambda2 = lambda(2,:);
Sigma = T + I;
obs_Sigma = g(1,:);

% Avoid division by zero
Sigma(Sigma <= 0) = eps;
obs_Sigma(obs_Sigma <= 0) = eps;

virus_grad = d * I .* lambda2;

% Total gradient with regularization

gm = gamma * (eta(i,:) - eta(1,:)) + virus_grad;
%gm =  virus_grad;

      	bs = (norm(gm)/norm(gn))^2;         %For CGA: bs=beta= optimal beta in updates of dm
        dm = -gm + bs*dn;
        bm = -(gm*dn')/(gamma*(dn*dn'));      %rm = -<g,d>/gamma<d,d>
        grad_hist(i,:) = gm;                  %Save gradient for later plot.
	step_hist(i,:) = dm;                  % save step length for history

	norm_grad_hist(i) = 	norm(gm);  % save norm of the gradient for visualization
	
        if norm(gm) < 0.001                %Check if gradient is small enough.
        %    eta(i+1:end,:) = ones(length(i+1:optim_maxiter),1)*eta(i,:);
		  eta(i+1:end,:) = ones(length(i+1:optim_maxiter),1)*eta(1,:);										
            grad_hist(i+1:end,:) = ones(length(i+1:optim_maxiter),1)*grad_hist(i,:);
            disp('The algorithm has converged!')
            break
        elseif 0.999999*norm(eta(i-1,:)) < norm(eta(i,:)) && norm(eta(i,:)) < 1.000001*norm(eta(i-1,:))
            eta(i+1:end,:) = ones(length(i+1:optim_maxiter),1)*eta(i,:);
            grad_hist(i+1:end,:) = ones(length(i+1:optim_maxiter),1)*grad_hist(i,:);
            disp('E(t) does not change!')    %Also terminate if eta stabilizes.
            break
        else
            gm = sign(gm);             %Otherwise, continue with line search.

	      
            for j = 1:nodes
		      eta(i+1,j) = eta(i,j) - beta(j)*gm(j);      %Compute new eta closer to the actual solution.
                if eta(i,j) < 1                                 %Force  E=1 if computed E is negative.
                    eta(i+1,j) = 1;
                elseif eta(i,j) > 10                             %Force E=10 if computed E > 10.
                    eta(i+1,j) = 10;
                elseif bm < 0.01
                    eta(i+1,j) = eta(i,j) - bm*gm(j);           %Use conjugate gradient if appropriate.
                else
                    if gm(j) == -gn(j)                          %Otherwise use fixed step length.
                        beta(j) = beta(j)/2;                    %If gradient change sign, halve step-length.
                    end
                   
                end
            end
        end

		  % compute norm of the relative error in the computed E(t)
		  
    
		  norm_grad_coef(i) =  norm(eta(i,:)- eta(i-1,:))/norm(eta(i,:));
	  
        gn = gm;                %Save gradient for use in the CG algorithm.
        dn = dm;
        iter = iter + 1;
    end


    iter

	    	big_grad = zeros(1,length(eta));
	  	residual = ones(1,length(eta));
   
    %%  here we define parameter beta: how much refine the mesh: take beta=0.99,0.95,...,0.5
    %==============================================================
		  
% Virus residual
		  res_virus = abs(abs(log10(u(3,:))) - abs(log10(g(3,:))));

% initial residual for virus
res_virus_init = abs(abs(log10(u1(3,:))) - abs(log10(g(3,:))));

% Sigma residual (T + I)  after optimization
Sigma = u(1,:) + u(2,:);

% Sigma residual (T + I)    before optimization
Sigma_init = u1(1,:) + u1(2,:);


obs_Sigma = g(1,:);

% Avoid log10(0)
Sigma(Sigma <= 0) = eps;
obs_Sigma(obs_Sigma <= 0) = eps;

res_sigma = abs(abs(log10(Sigma)) - abs(log10(obs_Sigma)));

res_sigma_init = abs(abs(log10(Sigma_init)) - abs(log10(obs_Sigma)));


% Combine both residuals (e.g., average)  before optimization
residual_common_init = res_virus_init + res_sigma_init;  % Compute it once

% Combine both residuals (e.g., average)  after optimization
residual_common = res_virus + res_sigma;  % Compute it once

%*************'  1-th mesh refinement criterion
% here is one of the criterions how to refine time-mesh
%for j = 1:length(big_grad)
%    if abs(residual_common(j)) > 0.9 * max(abs(residual_common(2:end)))
%        big_grad(j) = 1;
%    end
% end											

    %********** 2-nd mesh refinement criterion ***************

%   we refine the mesh at the points where is the biggest computed  gradient

    
for j = 1:length(big_grad)
	  if abs(grad_hist(optim_maxiter,j)) > meshref_beta(4)* max(grad_hist(optim_maxiter,:))
        big_grad(j) = 1;
    end
end
    


    %************************************************************************'				
    refined = [];               %Start refinement of time mesh ...
    refining = [];
    k = 1;
    r = 1;
    while r < length(big_grad)
        if big_grad(r+1) == 1 && big_grad(r) == 0
            refined = [refined,time_mesh(k:r)];
        end
        if big_grad(r) == 0
            r = r + 1;
            if r == length(big_grad)
                refined = [refined,time_mesh(k:r)];
            end
            continue
        else
            %j = i;
            while big_grad(r) == 1 && r < length(time_mesh)
                refining = [refining,time_mesh(r),(time_mesh(r)+time_mesh(r+1))/2];
                r = r + 1;
                if r == length(time_mesh)
                    refining = [refining,time_mesh(r)];
                end
            end
            refined = [refined, refining];
            k = r;
        end
        refining = [];
    end
    
eta_final = eta(end,:);
relativeerror = norm(eta(end,:)- eta_guess)/norm(eta_guess);
											    
reler(meshref) = relativeerror;
numbertimes(meshref) = size(time_mesh, 2);

%**********  plot norm of the computed relative error of the computed optimal   E(t) ******************************

figure

   %	plot(iteration_mesh,norm_grad_coef,' - d r','LineWidth',2)
plot(iteration_mesh(2:optim_maxiter),norm_grad_coef(2:optim_maxiter),' - d r','LineWidth',2)

		axis([1 optim_maxiter   0 0.5])										

 
     	    xlabel('iterations in CGA')

title(['Norm of the relative error in the computed E(t), nr. of ref.: ',num2str(meshref-1)])				
  saveas(gcf,'norm_error_E.png');

%*************************  end of visualization of an adaptive solution *******************************


meshref

numbertimes
  %  plot(time_mesh, eta(end,:)) %Plot calculated eta for each iteration in time adaptive algorithm.

%end
reler

min_time_step
max_time_step 


% presentation of the computed gradient
figure
grad_hist = real(grad_hist);  % Ensure it's real
  surf(grad_hist)
xlabel('time partition');
ylabel('iteration');
zlabel('gradient');
%title('Gradient  ');
 title(['Gradient, nr. of iter.: ',num2str(iter),', nr. of obs.points: ',num2str(m),', nr. of ref.: ',num2str(meshref-1)])	
%**********  plot norm of the computed gradient ******************************

figure

   %	plot(iteration_mesh,norm_grad_hist,' -o b','LineWidth',2)

 plot(iteration_mesh(2:optim_maxiter),norm_grad_hist(2:optim_maxiter),' -o b','LineWidth',2)

		axis([1 optim_maxiter   0 30])									       
     	    xlabel('iterations in CGA')

      	title(['Convergence of the norm of the gradient, nr. of ref.: ',num2str(meshref-1)])				

  saveas(gcf,'norm_grad_CGA.png');

 %********************************************* 


eta_smooth = LinearClassAdapt(eta_final, time_mesh,m,meshref,eta_guess);


%*********  begin of plot comparison between exact,  computed eta via LS
		       								    %   **********and computed eta via CGM **********
figure
%plot(time_mesh,eta_guess,'LineWidth',2)
	 %	   hold on
   	plot(time_mesh,eta_guess,' -.  b','LineWidth',2)
												hold on
   %	plot(time_mesh,eta_final,'-- r','LineWidth',2)		   
      	plot(time_mesh,eta_smooth,'- m','LineWidth',2)
		axis([0 365 1 5])
  
%  legend('initial guess for E_\tau^0','computed E(t) (CGM)','computed E(t) (CGM after LS)')

   mesrefinement = meshref-1;
    legend('initial guess for E_\tau^0','computed E_\tau, (CGM + LS)')
												
	   
     	    xlabel('Time, t')

      	title(['Computed E, nr. of iter.: ',num2str(iter),', nr. of obs.points: ',num2str(m),', nr. of ref.: ',num2str(meshref-1)])										
hold off

if (meshref==1) 
	 saveas(gcf,'RecEref0.png');
elseif (meshref==2)
	 saveas(gcf,'RecEref1.png');
elseif (meshref==3)
	 saveas(gcf,'RecEref2.png');
elseif (meshref==4)
	 saveas(gcf,'RecEref3.png');
elseif  (meshref==5)
	 saveas(gcf,'RecEref4.png');
 else
    saveas(gcf,'RecEfinal.png');
end

  
% print('RecE','-depsc')	   

%*****************  plotting optimized  solutions u(1), u(2) and u(3)

figure
	    	plot(time_mesh,log10(u(1,:)),'b - ', 'LineWidth',2)  
   hold on

    	plot(time_mesh,log10(u(2,:)),'g - ', 'LineWidth',2)
  
	plot(time_mesh,log10(u(3,:)),'k - ', 'LineWidth',2)  
  
	      	plot(time_mesh,log10(g(3,:)),' r -- ', 'LineWidth',2)

  	plot(time_mesh,log10(g(1,:)),'m -. ', 'LineWidth',2)
  
xlabel(' mesh in time ');
%ylabel(' functions');

%legend('computed V','observations g_3','Location','southeast');


legend('u_1',' u_2',' u_3 ','observations Virus','Observations Sigma = T+I',  'Location','southeast');

str_title = ['Iteration ',num2str(iter),', nr.of mesh ref.',num2str(meshref-1)];
       	title(str_title);							


if (meshref==1) 
	 saveas(gcf,'OptimumMref0.png');
elseif (meshref==2)
	 saveas(gcf,'OptimumMref1.png');
elseif (meshref==3)
	 saveas(gcf,'OptimumMref2.png');
elseif (meshref==4)
	 saveas(gcf,'OptimumMref3.png');
elseif  (meshref==5)
	 saveas(gcf,'OptimumMref4.png');
 else
    saveas(gcf,'OptimumMfinal.png');
end

%**************  plotting optimized virus functions u(3), Sigma versus observations and compare it with measurements  *****

figure
plot(time_mesh, log10(u(3,:)), 'b-', 'LineWidth', 2) % Virus (u3)
hold on
  plot(time_mesh, log10(g(3,:)), 'm :', 'LineWidth', 2) % Observed virus



plot(time_mesh, log10(u(1,:) + u(2,:)), 'k -.', 'LineWidth', 2) % Sigma (T+I)
plot(time_mesh, log10(g(1,:)), 'r--', 'LineWidth', 2) % Observed Sigma

xlabel('Time (days)')
%  ylabel('log_{10} V,      log_{10} \Sigma')
legend(' u_3', 'Observed V', '  u_1 + u_2', 'Observed \Sigma', 'Location', 'southwest')
title(['Patient 1: optimized  Virus and \Sigma, CGA it. ', num2str(i),' mesh ref ', num2str(meshref - 1)])

if (meshref==1) 
	 saveas(gcf,'OptVirusref0.png');
elseif (meshref==2)
	 saveas(gcf,'OptVirusref1.png');
elseif (meshref==3)
	 saveas(gcf,'OptVirusref2.png');
elseif (meshref==4)
	 saveas(gcf,'OptVirusref3.png');
elseif  (meshref==5)
	 saveas(gcf,'OptVirusref4.png');
 else
    saveas(gcf,'OptVirusfinal.png');
end


%******************  plotting residual  for virus function:  R1 = u(3,:) - g(3,:)  *********************
												
%  residual =  abs(log10(u(3,:))  - log10(g(3,:)));
% residual_init =  abs(log10(u1(3,:)) - log10(g(3,:)));

	      	figure
		%	   	plot(time_mesh,residual,'r - ', 'LineWidth',2);
                plot(time_mesh,res_virus,'r - ', 'LineWidth',2);
       		hold on
	      %	plot(time_mesh,residual_init,'k -- ', 'LineWidth',2);
              plot(time_mesh,res_virus_init,'k -- ', 'LineWidth',2);

	  	legend('Optimized residual  R1','Initial residual  R1','Location','southeast');
str_title = ['Residual R1: CGA it.  ', num2str(iter),', nr.of mesh ref.:',num2str(meshref-1)];
       	title(str_title);							

if (meshref==1) 
	 saveas(gcf,'Residref0.png');
elseif (meshref==2)
	 saveas(gcf,'Residref1.png');
elseif (meshref==3)
	 saveas(gcf,'Residref2.png');
elseif (meshref==4)
	 saveas(gcf,'Residref3.png');
elseif  (meshref==5)
	 saveas(gcf,'Residref4.png');
 else
    saveas(gcf,'Residfinal.png');
end

%*************************************************************************
% presenting second residual for Sigma  R2 = (u(1,:)  + u(2,:))  - g(1,:) ***********************************
%*************************************************************************

  residual2 =  abs(log10(u(1,:)  + u(2,:))  - log10(g(1,:)));
residual_init2 =  abs(log10(u1(1,:)  + u1(2,:)) - log10(g(1,:)));

	      	figure
	   	plot(time_mesh,residual2,'r - ', 'LineWidth',2);
       		hold on
	      	plot(time_mesh,residual_init2,'k -- ', 'LineWidth',2);										
	  	legend('Optimized residual R2','Initial residual  R2','Location','southeast');
str_title = ['Residual R2: CGA it.  ', num2str(iter),', nr.of mesh ref.:',num2str(meshref-1)];
       	title(str_title);							

if (meshref==1) 
	 saveas(gcf,'Resid2ref0.png');
elseif (meshref==2)
	 saveas(gcf,'Resid2ref1.png');
elseif (meshref==3)
	 saveas(gcf,'Resid2ref2.png');
elseif (meshref==4)
	 saveas(gcf,'Resid2ref3.png');
elseif  (meshref==5)
	 saveas(gcf,'Resid2ref4.png');
 else
    saveas(gcf,'Resid2final.png');
end

%***************  visualization of the common residual before and after optimization      *******************
%**************************************************************************

	figure
	   	plot(time_mesh,residual_common,'r - ', 'LineWidth',2);
       		hold on
	      	plot(time_mesh,residual_common_init,'k -- ', 'LineWidth',2);										
	  	legend('Optimized  R1 + R2','Initial residual  R1 + R2','Location','southeast');
str_title = ['Common residual R1 + R2: CGA it.  ', num2str(iter),', nr.of mesh ref.:',num2str(meshref-1)];
       	title(str_title);							

if (meshref==1) 
	 saveas(gcf,'ResidCommonref0.png');
elseif (meshref==2)
	 saveas(gcf,'ResidCommonref1.png');
elseif (meshref==3)
	 saveas(gcf,'ResidCommonref2.png');
elseif (meshref==4)
	 saveas(gcf,'ResidCommonref3.png');
elseif  (meshref==5)
	 saveas(gcf,'ResidCommonref4.png');
 else
    saveas(gcf,'ResidCommonfinal.png');
end

%***********************************************************************
% computation of absolute residuals
refined_residual_virus(meshref) = norm(res_virus);
refined_residual_sigma(meshref) = norm(res_sigma);
refined_residual_common(meshref) = norm(residual_common);


% computation of relative residuals

rel_res_common(meshref) =  norm(residual_common)/size(residual_common,2);
rel_res_virus(meshref) = norm(res_virus)/size(residual_common,2);
rel_res_sigma(meshref) = norm(res_sigma)/size(residual_common,2);

rel_res = residual_common./size(residual_common,2)
refined_rel_residual(meshref) =  norm(rel_res)

  
    
 mesh_meshref  = linspace(1,meshref,meshref);
	figure
	plot(mesh_meshref,refined_residual_virus,'b --d ', 'LineWidth',2);
   hold on
   	plot(mesh_meshref,refined_residual_sigma,'m --d ', 'LineWidth',2);
plot(mesh_meshref,refined_residual_common,'r --d ', 'LineWidth',2);

legend('R_1 = || log_{10}(u(3)) - log_{10}(g(3) ) ||',' R_2 = || log_{10}(u(1)+ u(2))  - log_{10}(sigma) ||','R_1 + R_2 ');

xlabel('Number of mesh refinements')


% presentation of relative residuals

	figure
	plot(mesh_meshref,rel_res_virus,'b --d ', 'LineWidth',2);
   hold on
   	plot(mesh_meshref,rel_res_sigma,'m --d ', 'LineWidth',2);
plot(mesh_meshref,rel_res_common,'r --d ', 'LineWidth',2);

legend('R_1 = || log_{10}(u(3)) - log_{10}(g(3) ) ||/nno',' R_2 = || log_{10}(u(1)+ u(2))  - log_{10}(sigma) ||/nno','R_1 + R_2 ');

xlabel('Number of mesh refinements')
  %********* smoothing: polynomial fitting to the reconstructed function

eta_new = LinearClassAdapt(eta_smooth', time_mesh,m,meshref,eta_guess);

unew = ForwardNewtonCTL(d_CTL,eta_new,time_mesh);                     %Compute  forward sol.


  
%*****************  end of plot ********************************************************************
	

if ( relativeerror < eps)
			  break
end

												
 %   if (meshref > 1 &  refined_residual_common(meshref) >   refined_residual_common(meshref-1))
 %  break
 %    end

     if (meshref > 1 & refined_rel_residual(meshref) >  refined_rel_residual(meshref-1))
 break
     end


     
     %another stopping criterion for mesh refinements
%  if (meshref > 1 & relativeerror >  reler(meshref-1) )
%                 break
%             end
		  
 %time_mesh = old_mesh; % to save this mesh for interpolation of reconstruction and data  on the new refined mesh
 old_mesh = time_mesh;



% here we save information for every beta

%ref_residual_hist(1,:) = refined_residual_common(meshref);
%ref_residual_hist(2,:) =  meshref_beta(count_beta);
%ref_residual_hist(3,:) = meshref;

%end



% here is end for mesh refinements
end

