%Computes the forward solution of the model problem.
function [u] = ForwardNewtonCTL(d_CTL,E,time_mesh)

% parameters from the table 1 in the paper
s=10000;
mu=0.01;
beta1 = 2.4e-8;
beta2 = 2.4e-8;

%d=0.26;
c=2.4;
rho=1000;


t=0;  % initial time

time_moments = length(time_mesh)-1;

%ustart = [300;10;10];    %Initial values for u
ustart = [112500;0;1];    %Initial values for u - write correct values
      
v=ustart;


MaxIter = 1000;  % maximal number of iterations in Newton method

u = zeros(3,time_moments+1);
u(:,1) = ustart;
%u_hist=[u];     %Save all u values for later plot

dt = zeros(1,length(time_mesh));
for i = 1:length(dt)-1
  dt(i) = time_mesh(i+1)-time_mesh(i);   %Time step
end

%set_tolerance = 10^(-10);
set_tolerance = 10^(-8);

for i = 1:time_moments   % Here we define final time
    tol=1;
    iter=0;
    while tol>  set_tolerance && iter < MaxIter   %Newton iterations
%    F= v-u(:,i)-dt*Forwardfunc(v,eta(i));
%    J=eye(length(ustart)) - dt.*ForwardfuncJac(v,eta(i));
F= v-u(:,i)-dt(i)*Forwardfunc3eqCTL(v,E(i),s,mu,beta1,beta2,d_CTL(i),c,rho);
J=eye(length(ustart)) - dt(i)*ForwardfuncJac3eqCTL(v,E(i),s,mu,beta1,beta2,d_CTL(i),c,rho);
    dv = -J\F;
     v=v+dv;              %The Newton iteration 
     iter = iter +1;
     tol = norm(dv,inf);
    end  
    if iter==MaxIter        %If the Newton meth. does not converge
        disp(' Newtons method achieved max.nr.of iterations')
        break
    end
   %   disp('Newton method converged at iteration:')
    %  iter
    if v(1) < 0 || v(2) < 0 || v(3) < 0
        warning('Forward solution algorithm yields invalid solution. Try increasing the number of time_moments in the time partition.')
        return
    end
    u(:,i+1) =  v;        
    t=t+dt(i);
i;
   %u_hist=[u_hist,u];

end

%************  plotting of all 3 solutions *******************
%figure
%plot(time_mesh,log10(u),'LineWidth',2)

%plot(time_mesh,log10(u(1,:)),':  m','LineWidth',2);
%hold on;
%plot(time_mesh,log10(u(2,:)),'-- b','LineWidth',2);
%plot(time_mesh,log10(u(3,:)),'-  r','LineWidth',2);


%xlabel('time interval, days');
%ylabel('computed solution');
%ylabel('log_{10} u(t)');
%legend('log_{10} u_1','log_{10} u_2','log_{10} u_3','Location','SouthEast');

%str_title = [' E = ', num2str(E(1))];

%str_title = ['forward solution, nr. of iter.', num2str(m)];
%title(str_title)
%saveas(gcf,'u1u2u3.png');
   %******************************************************************
%************  plotting  of  function u_1  *******************
%******************************************************************
%figure
%plot(time_mesh,log10(u(1,:)),'LineWidth',2)
%xlabel('time interval, days');
%ylabel('log_{10} u_1(t)');
%legend('log_{10} u_1','Location','SouthEast');
%str_title = [' E = ', num2str(E(1))];
%title(str_title)
%saveas(gcf,'u1.png');
   %******************************************************************
%************  plotting  of  function u_2  *******************
%******************************************************************
%figure
%plot(time_mesh,log10(u(2,:)),'LineWidth',2)
%xlabel('time interval, days');
%legend('log_{10} u_2','Location','SouthEast');
%str_title = ['E = ', num2str(E(1))];
%title(str_title)
%saveas(gcf,'u2.png');

   %******************************************************************
%************  plotting  of virus function u_3  *******************
%******************************************************************

%figure
%plot(time_mesh,log10(u(3,:)),'LineWidth',2)

%xlabel('time interval, days');
%ylabel('log_{10} u_3(t)');
%legend('log_{10} u_3(t)','Location','SouthEast');

%str_title = [' E = ', num2str(E(1)) ];
%title(str_title)
%saveas(gcf,'u3.png');

%InterpolVDays_Patient1 = Function_LinearIntVDaysPatient1(-1,52);

%figure
%t1 = linspace(0,363,364);
%plot(t1,InterpolVDays_Patient1 ,'- b', 'LineWidth',2)
%hold on


%plot(time_mesh,log10(u(3,:)),'-- m','LineWidth',2)

%legend('interpolated log_{10} V(t) data in days','computed u_3: log_{10} V(t) in days','Location','SouthEast');
  
% xlabel(' time in days')
%  ylabel('log_{10} V(t)  ')

% str_title = ['Patient 1: observations versus computed solution '];
%title(str_title)

% title('Patient 1: observations versus computed solution u_3(t) = V(t)')

%  saveas(gcf,'u3versusdata.png');
end

