function [ f ] = Forwardfunc3eq(u,E,s,mu,beta1,beta2,d,c,rho)
%The function f in the problem: u'=f(u)

f=zeros(3,1);  



f(1)= s - beta1*u(1)*u(3)-mu*u(1);      
f(2)=beta1*u(1)*u(3)- d*u(2)*E; 
f(3)= rho*u(2)- beta2*u(1)*u(3)-c*u(3);

end

