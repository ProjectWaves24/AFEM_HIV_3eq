function [Jac ] = ForwardfuncJac3eqCTL(u,E,s,mu,beta1,beta2,d,c,rho)
% The Jacobian for our problem
% Input: u      (point)
% Output: Jac   (Jacobian in point u)



Jac=[-beta1*u(3) - mu,  0, -beta1*u(1);
       beta1*u(3), -E*d, beta1*u(1);
       -beta2*u(3), rho, -beta2*u(1) - c];




end

