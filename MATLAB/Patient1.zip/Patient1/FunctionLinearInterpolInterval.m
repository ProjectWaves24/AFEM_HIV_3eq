function [interpol_value] = FunctionLinearInterpolInterval(a,b,k,x,y)
  


% Linear interpolation for 2 points, k and k+1, of the interval [x_k,x_k+1]:
  %  y = y_k + (x - x_k) (y_k+1 - y_k)(x_k+1 - x_k)
 
  nom = y(b) - y(a);
denom = x(b)-x(a);
   interpol_value = y(a) + (x(k) - x(a))*(nom/denom);

		       end
  
