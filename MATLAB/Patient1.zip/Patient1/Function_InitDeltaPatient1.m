function [Delta,newE] = Function_InitDeltaPatient1(delta,beta,t1,t2,deltaT1,deltaT2,observations_V,t,E,observations_sigma)
  
%close all
%clear all

  kappa = 1.0 + 10^5*beta;
  
  for i=1:length(observations_V)
    deriv1 = (t(i) - t1)/deltaT1;
    deriv2 =  (t(i) - t2)/deltaT2;
    denom1(i) = 1.0 + kappa*exp(-deriv1);
    denom2(i) = 1.0 + kappa*exp(-deriv2);
    time_func(i) = beta/denom1(i) - beta/denom2(i);
    newE(i) = E(i) +  time_func(i)*log10(observations_V(i));
    Delta(i) = delta + time_func(i)*log10(observations_V(i));
    end

  

% plotting the whole data (old and new interpolated)
  figure
  plot(t, log10(observations_V),'d  b',  'LineWidth',2)
  
 % hold on
 % plot(t, Delta,'o  r',  'LineWidth',2)
 % legend('virus function, log_{10} V(t) ',' d  with CTL response');
    legend('virus function, log_{10} V(t) ');
  xlabel(' Time, days')
%  ylabel('log_{10}   ')
  title('Patient 1')
  saveas(gcf,'V3Delta.png');

  % plotting for Sigma =(T + I) observations
figure
plot(t, log10(observations_sigma), 'o b', 'LineWidth', 2)
legend('log_{10} \Sigma(t) ')
xlabel('Time, days')
ylabel('log_{10} \Sigma(t)')
title('\Sigma,  Observations for Patient 1')
saveas(gcf, 'SigmaObservations.png');


  figure
  
  plot(t,time_func,'- k',  'LineWidth',2)
  legend('f(t), Effect of CTL response');
  
 xlabel(' time in days')
%  ylabel('log_{10} V(t)  ')

 saveas(gcf,'fCTL.png');
 
 figure
 plot(t, newE,'d  r',  'LineWidth',2)
   legend(' E  with CTL response');
  xlabel(' time in days')
  ylabel('E(t)  ')
 title('Patient 1')
 saveas(gcf,'ECTL.png');
 
 figure
 plot(t, Delta,'o  k',  'LineWidth',2)
   legend(' d  with CTL response');
  xlabel(' time in days')
  ylabel('d(t)  ')
 title('Patient 1')
 saveas(gcf,'InitDelta.png');

 
		       end
  
