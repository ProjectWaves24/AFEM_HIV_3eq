function [InterpolSigmaDays] = Function_LinearIntSigmaDaysPatient1(n,p)

% Definition of interpolation interval [n,p]

fun_exact = 0;
fun_val = 0;

% We have 8 observations from Table 2
N = 8;

x = [-1,0,1,2,3,4,26,52];
x_exact = x;

% Observations for log10(Sigma) = log10(T + I) (from Table 2)
y = log10([1125, 825, 675, 525, 540, 525, 550, 600] * 1e3);
% Linear interpolation
for i = 1:N
    for k=1:N-1
        if (x_exact(i) <= x(k+1)  && x_exact(i) >= x(k))
            nom = y(k+1) - y(k);
            denom = x(k+1)-x(k);
            Linear_spline(i) = y(k) + (x_exact(i) - x(k)) * (nom/denom);
        end
    end
end

% Interpolation between 4 weeks and 26 weeks
x1 = linspace(4, 26, 23);
k = 6;
for i = 1:23
    nom = y(k+1) - y(k);
    denom = x(k+1)-x(k);
    Linear1(i) = y(k) + (x1(i) - x(k)) * (nom/denom);
end

% Interpolation between 26 weeks and 52 weeks
x2 = linspace(26, 52, 27);
k = 7;
for i = 1:27
    nom = y(k+1) - y(k);
    denom = x(k+1)-x(k);
    Linear2(i) = y(k) + (x2(i) - x(k)) * (nom/denom);
end

% Combine interpolated values
for k = 1:6
    interpolated_data(k) = y(k);
    t(k) = k;
end

sch = 1;
for k = 6:28
    interpolated_data(k) = Linear1(sch);
    sch = sch + 1;
    t(k) = k;
end

sch = 1;
for k = 28:53
    interpolated_data(k) = Linear2(sch);
    sch = sch + 1;
    t(k) = k;
end

% Interpolation from weeks to days (52 weeks -> 364 days)
t1 = linspace(0, 363, 364);
new_time = 7*t - 7;
sch = 1;

for k = 1:52
    nom = interpolated_data(k+1) - interpolated_data(k);
    denom = new_time(k+1)- new_time(k);
    for i = 1:7
        InterpolSigmaDays(sch) = interpolated_data(k) + (t1(sch) - new_time(k)) * (nom/denom);
        sch = sch + 1;
    end
end

% Plot results
figure
plot(new_time, interpolated_data, '- b', 'LineWidth', 2)
hold on
plot(t1, InterpolSigmaDays, 'o m', 'LineWidth', 2)
legend('log_{10} \Sigma (in weeks)',' interpolated log_{10} \Sigma (in days) ');
xlabel('Time, days');
ylabel('log_{10} \Sigma ');
title('Patient 1: Interpolated Clinical Data ')
saveas(gcf, 'InterpolatedSigmaDataPat1.png');
end
