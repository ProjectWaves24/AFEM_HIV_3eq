function [InterpolVDays] = Function_LinearIntVDaysPatient1(n,p)
  
%close all
%clear all

% definition av interpolation intervalet [n,p]

%n= -1.0;
%p= 52.0

fun_exact = 0;
fun_val = 0;

% we have 8 observations
N = 8;


x = [-1,0,1,2,3,4,26,52]
  x_exact =  x;


% observations for log_10 V(t)

y(1) =  0.0;
y(2) = 5.5;
y(3) = 7.75;
y(4) = 6.5;
y(5) = 5.5;
y(6) = 5.3;
y(7) = 4.5;
y(8)  = 5.1;




% Linear interpolation for 2 points, k and k+1, of the interval [x_k,x_k+1]:
  %  y = y_k + (x - x_k) (y_k+1 - y_k)(x_k+1 - x_k)
  for i = 1:N
for k=1:N-1
	if (x_exact(i) <= x(k+1)  && x_exact(i) >= x(k))
  nom = y(k+1) - y(k);
denom = x(k+1)-x(k);
Linear_spline(i) = y(k) + (x_exact(i) - x(k))*(nom/denom);
end
end
end

%interpolation between 4 weeks and 26 weeks on the time interval [4,26]

x1 = linspace(4, 26, 23);

% we take the point number 6 from observations
k=6;
 for i = 1:23
 nom = y(k+1) - y(k);
denom = x(k+1)-x(k);
Linear1(i) = y(k) + (x1(i) - x(k))*(nom/denom);
end

%here we interpolation between 26 weeks and 52 weeks on the time interval [26,52]

x2 =  linspace(26,52, 27);

% we take the point number 7 from observations
k=7;
 for i = 1:27
 nom = y(k+1) - y(k);
denom = x(k+1)-x(k);
Linear2(i) = y(k) + (x2(i) - x(k))*(nom/denom);
end
  

% presentation of interpolation	

%**************  Figure 1: presentation of interpolation at 8 points
%figure

%plot(x, y,'o b',  'LineWidth',2)

%hold on
%  plot(x_exact,Linear_spline, ' g -',  'LineWidth',2)

%hold off

%legend('log_{10} V(t) data', 'linear interpolant');
  
%  xlabel(' time in weeks')
%  ylabel('log_{10} V(t)  ')

%  title('Patient 1: linear interpolation at 8 observation points')

  %****************** Figure 2: presentation of internal points
%figure

%plot(x, y,'o b',  'LineWidth',2)

%hold on
%  plot(x_exact,Linear_spline, ' g -',  'LineWidth',2)

% plot(x1,Linear1, ' m o',  'LineWidth',2)
% plot(x2,Linear2, ' m o',  'LineWidth',2)
  
%  hold off
%  legend('log_{10} V(t) data', 'linear interpolant','interpolated internal points');
  
%  xlabel(' time in weeks')
%  ylabel('log_{10} V(t)  ')

%  title('Patient 1: linear interpolation at 52 observation points')
 
%  Linear1
%  Linear2
%===================
 for k = 1:6
   interpolated_data(k) =  y(k);
	   t(k) = k;
	   end
	   
	   sch = 1;
	   for k = 6:28
		     interpolated_data(k) =  Linear1(sch);
               sch = sch +1;
t(k) = k;
	   end
 sch = 1;
		     for k = 28:53
			       interpolated_data(k) =  Linear2(sch);
                              sch = sch +1;
t(k) = k;
	             end

% plotting the whole data (old and new interpolated)
%		     figure

%plot(t, interpolated_data,'-o b',  'LineWidth',2)


%*************  linear interpolation from weeks to days for 1 year : we interpolate data from 52 weeks into 364 days
% first we present interpolated weakly data as data for the whole year in days
		     

		     
		     t1 =  linspace(0,363, 364);

		     sch = 1;
		    % for j = 1:365
		    %        if  ( rem(j,7) == 0)
		    %          new_time(sch) = 7*sch; 
		%	      sch = sch+1;
		%	    end
		 %    end
		     
                  
		     new_time = 7*t - 7;
		     
 sch = 1;  % counter for days
		     
		       for k = 1:52
			 nom = interpolated_data(k+1) - interpolated_data(k);
			 %denom = t(k+1)-t(k);
			  denom = new_time(k+1)- new_time(k);

			 for i = 1:7
			  % 	if (t1(sch) <= t(k+1)  && t1(sch) >= t(k))
			   InterpolVDays(sch) = interpolated_data(k) + (t1(sch) - new_time(k))*(nom/denom);
			 sch = sch + 1;
			 end
			% end
		       end
		      	 

		       size(InterpolVDays)
% plotting the whole data (old and new interpolated)
		     figure

		     plot(new_time, interpolated_data,'- b',  'LineWidth',2)

		    hold on
		      plot(t1, InterpolVDays,'o  m',  'LineWidth',2)

	  legend('log_{10} V ( in weeks)','interpolated log_{10} \Sigma (in days)');
  
 xlabel(' time in days')
  ylabel('log_{10} V  ')

 title('Patient 1: Interpolated Clinical Data  ')
	 saveas(gcf,'InterpolatedVirusDataPat1.png');	      
		       end
  
