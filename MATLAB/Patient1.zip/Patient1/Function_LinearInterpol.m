function [new_func] = Function_LinearInterpol(old_mesh,new_mesh,old_func)
  
  new_func =  zeros(1,length(new_mesh));

  % first we assign old values of function to the corresponding nodes in a new refined mesh
for  j=1:length(new_mesh)
  for i = 1:length(old_mesh)
    if new_mesh(j) - old_mesh(i) == 0
        new_func(j) = old_func(i);
      break
    end
  end
end

% then we interpolate into new nodes in the mesh using old values of function which are already assigned in the previous loop
for  j=2:length(new_mesh)-1
  if new_func(j) == 0.0
    interpol_value =FunctionLinearInterpolInterval(j-1,j+1,j,new_mesh,new_func);
    new_func(j) =  interpol_value;
  end
  end




end
  
