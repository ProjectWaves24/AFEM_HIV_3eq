function [eta_guess, g_obs] = GuessEta_fromSigma(E, observations, time_mesh, obs_start, obs_end, meshref)

    nodes = length(time_mesh) - 1;
    time_step = zeros(1, length(time_mesh));
    for i = 1:length(time_step) - 1
        time_step(i) = time_mesh(i+1) - time_mesh(i);
    end

    g = zeros(3, length(observations));
    g_obs = zeros(3, length(observations));
    eta_guess = zeros(1, length(observations));

    % Fill Sigma values in g(1,:)
    g(1,:) = observations;
    g_obs(1,:) = observations;

    % Zero out observations outside interval and assign eta_guess
    t = 0;
    dt = zeros(1, length(time_mesh));

    for i = 1:length(dt) - 1
        dt(i) = time_mesh(i+1) - time_mesh(i);

        if t < obs_start || t >= obs_end
            g_obs(1,i) = 0;
            g_obs(1,i+1) = 0;
        end

        eta_guess(i) = E(i);
        eta_guess(i+1) = E(i+1);

        t = t + dt(i);
    end

    % Optional plotting
    % figure;
    % plot(time_mesh, g_obs(1,:), 'r--', 'LineWidth', 2);
    % xlabel('Time'); ylabel('\Sigma (T + I)');
    % legend('Observed \Sigma (masked)');
    % title(['Sigma observations, mesh ref ', num2str(meshref-1)]);

end
