function [eta_guess,g_obs] = GuessEta_fromVirus(E,observations,time_mesh,obs_start,obs_end,meshref)
   
    %final_time = time_mesh(end);
    nodes = length(time_mesh)-1;
    time_step = zeros(1,length(time_mesh));
    for i = 1:length(time_step)-1
        time_step(i) = time_mesh(i+1)-time_mesh(i);
    end                                 %Time step for discrete derivatives.
  %  g_prim = zeros(4,nodes+1);
    eta = zeros(1,nodes+1);
    %Simulate the true values of the model problem, with and without noise.
    %[g,g_brus,g_add] =  ExactNewton(ext_eta,time_mesh,noise_level);
   
    g = zeros(3,length(observations));
    g_obs = zeros(3,length(observations));

    eta_guess =  zeros(1,length(observations));
    g(3,:) = observations;
     g_obs(3,:) = observations;
    
%****************  before plotting data and fitting to data (initial guess for eta)***********************************

size(g)

size(time_mesh)

%figure
%plot(time_mesh, g(3,:),'-* b', 'linewidth',2)
%hold on


%*********  we zero out observation data outside the observation interval
final_time = time_mesh(end); % the final time
t=0; 
dt = zeros(1,length(time_mesh));
 
for i = 1:length(dt)-1
    dt(i) = time_mesh(i+1)-time_mesh(i);   %Time step
     
    if t >= obs_end || t < obs_start
        g_obs(3,i) = 0;
         g_obs(3,i+1) = 0;
    end
% assign value of initial guess for parameter
    eta_guess(i) = E(i);
    eta_guess(i+1) = E(i+1);
    
    t=t+dt(i);
     
end


%plot(time_mesh,g_obs(3,:),'o ', 'linewidth',2)


%xlabel('Time')
%ylabel('u_3')
%legend('observed data u_3, whole interval',' observed data u_3, interpolated observations');
%title(['Nr. of ref.: ',num2str(meshref-1)'])

%hold off
%******************************  end of plotting u_4 ***********************************************************
     
 %   figure  
 %   plot(time_mesh,eta_guess,'o','linewidth',2)
 % legend('guess for \eta')


end
