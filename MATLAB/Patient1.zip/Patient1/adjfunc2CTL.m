function adjf = adjfunc2CTL(d, lambda, u, g, eta)
  % The rhs f(lambda) in the adjoint problem: lambda' = f(lambda)

  adjf = zeros(3,1);  

  % Parameters from Table 1 in the paper
  s = 10000;
  mu = 0.01;
  beta1 = 2.4e-8;
  beta2 = 2.4e-8;
  c = 2.4;
  rho = 1000;

  % Compute additional term from Eq. (4.17) for adjf(1) and adjf(2)
  if (u(1) + u(2)) > 0 % Avoid division by zero
      coef1 = 1.0 / ((u(1) + u(2))*log(10));  
      term1 = coef1 * (log10(u(1) + u(2)) - log10(g(1)));
  else
      term1 = 0;
  end

  % Compute additional term from Eq. (4.17) for adjf(3)
  if u(3) > 0  % Avoid division by zero
      coef3 = 1.0 / (u(3)*log(10));  
      term3 = coef3 * (log10(u(3)) - log10(g(3)));
  else
      term3 = 0;
  end

  % Update adjoint function equations
  adjf(1) = lambda(1) * beta1 * u(3) + lambda(1) * mu - lambda(2) * beta1 * u(3) + beta2 * lambda(3) * u(3) + term1;
  adjf(2) = lambda(2) * d * eta - rho * lambda(3) + term1;
  adjf(3) = beta1 * lambda(1) * u(1) - beta1 * lambda(2) * u(1) + c * lambda(3) + beta2 * lambda(3) * u(1) + term3;

end
