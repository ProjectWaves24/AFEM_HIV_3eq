function [adjJac] = adjfuncJacCTL(d,u,eta)
% The Jacobian for the adjoint problem
% Input: u      (point)
% Output: adjJac   (Jacobian for the adjoint equation in point u)



% parameters from the table 1 in the paper
s=10000;
mu=0.01;
beta1 = 2.4e-8;
beta2 = 2.4e-8;
%d=0.26;
c=2.4;
rho=1000;


adjJac=[beta1*u(3) + mu,  -beta1*u(3), beta2*u(3);
	0,   d*eta, -rho;
	beta1*u(1), -beta1*u(1), c + beta2*u(1)];



end



